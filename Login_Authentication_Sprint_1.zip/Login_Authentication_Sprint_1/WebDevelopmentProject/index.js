const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const collection = require('./config');

const app = express();
app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.render('login');
});

app.get('/signup', (req, res) => {
    res.render('signup');
});
app.get('/verify', (req, res) => {
    res.render('verify');
});

app.post("/signup", async (req, res) => {
    try {
        const existingUser = await collection.findOne({ email: req.body.email.trim() });
        if (existingUser) {
            return res.status(400).send("User already exists with the same email. Please choose a different email.");
        }

        const hashedPassword = await bcrypt.hash(req.body.password, 10);
        const newUser = await collection.create({
            name: req.body.name,
            username: req.body.username,
            contact: req.body.contact,
            email: req.body.email.trim(),
            city: req.body.city,
            gender: req.body.gender,
            password: hashedPassword
        });
        console.log("User created:", newUser);
        res.redirect("/"); // Redirect to the login page after signup
    } catch (err) {
        console.error("Error creating user:", err);
        res.status(500).send("Error creating user");
    }
});

app.post("/login", async (req, res) => {
    try {
        const user = await collection.findOne({ email: req.body.email });
        if (!user) {
            return res.status(404).send("User not found");
        }

        const validPassword = await bcrypt.compare(req.body.password, user.password);
        if (!validPassword) {
            return res.status(400).send("Invalid password");
        }

        res.render('home'); // Assuming home.ejs is your home page
    } catch (err) {
        console.error("Error logging in:", err);
        res.status(500).send("Error logging in");
    }
});

const port = 5000;
app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});
