function sendotp() {
    const email = document.getElementById('email').value;
    const otpverify = document.getElementsByClassName('otpverify')[0];
    let otp_val = Math.floor(Math.random() * 10000);
    let emailbody = `<h2>Your OTP is ${otp_val}</h2>`;

    Email.send({
        SecureToken: "00fc7561-fc3e-496e-a95c-84838add29ad",
        To: email,
        From: "hzma56jb@gmail.com",
        Subject: "Email OPT using Javascript",
        Body: emailbody,
    }).then(
        message => {
            if (message === "OK") {
                alert("OTP sent to your email " + email);
                otpverify.style.display = "flex";
                const otp_btn = document.getElementById('otp_btn');

                otp_btn.addEventListener('click', () => {
                    const otp_inp = document.getElementById('otp_inp').value;
                    if (otp_inp === otp_val.toString()) {
                        alert("Your Email Address Verified");
                    } else {
                        alert("Invalid OTP");
                    }
                });
            } else {
                alert("Failed to send OTP");
            }
        }
    );
}
